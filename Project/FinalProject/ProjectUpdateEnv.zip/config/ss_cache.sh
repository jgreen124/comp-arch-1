# config/ss_cache.sh

# SimpleScalar cache configuration parameters
# Add any custom cache configuration here
# Custom configurations will override the defaults set in env.sh

export SS_IL1_CONFIG="il1:32768:64:1:l"
export SS_DL1_CONFIG="dl1:32768:64:1:l"
export SS_UL2_CONFIG="ul2:262144:64:4:l"

