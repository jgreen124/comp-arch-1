// tasksys.cpp — minimal runtime matching ISPC symbols found in square_root_ispc_tasks.o
// (for ISPC 1.22–1.29 with 3-arg task entry, 4-param ISPCLaunch)

#include <pthread.h>
#include <vector>
#include <cstdint>
#include <cstdlib>
#include <cstring>

using ISPCTaskFunc = void (*)(void *data, int32_t threadIndex, int32_t threadCount);

struct ThreadInfo {
    ISPCTaskFunc func;
    void *data;
    int32_t tid;
    int32_t total;
};

static void *threadMain(void *arg) {
    ThreadInfo *t = (ThreadInfo *)arg;
    t->func(t->data, t->tid, t->total);
    return nullptr;
}

extern "C" {

// called internally by ISPC before launching
void *ISPCAlloc(void **handlePtr, int32_t size) {
    void *mem = std::malloc((size_t)size);
    if (mem) std::memset(mem, 0, (size_t)size);
    if (handlePtr) *handlePtr = mem;
    return mem;
}

// main task launcher: this is the ABI your .o expects
void ISPCLaunch(void *f, void *data, int /*count*/, int32_t taskCount) {
    ISPCTaskFunc func = (ISPCTaskFunc)f;

    if (taskCount <= 1) {
        func(data, 0, 1);
        return;
    }

    std::vector<pthread_t> threads(taskCount - 1);
    std::vector<ThreadInfo> info(taskCount);

    for (int32_t i = 0; i < taskCount; ++i)
        info[i] = { func, data, i, taskCount };

    for (int32_t i = 1; i < taskCount; ++i)
        pthread_create(&threads[i - 1], nullptr, threadMain, &info[i]);

    threadMain(&info[0]);
    for (auto &t : threads) pthread_join(t, nullptr);
}

// final sync call (no-op)
void ISPCSync(void * /*handle*/) {}

} // extern "C"
