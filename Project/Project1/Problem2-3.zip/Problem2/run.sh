#!/usr/bin/env bash
set -euo pipefail

# ------------ helpers ------------
die()  { echo "ERROR: $*" >&2; exit 1; }
msg()  { echo -e "\033[1;32m$*\033[0m"; }

# ------------ config ------------
BIN="${BIN:-./sqrt_compare}"
REPS="${REPS:-3}"
CSV="${CSV:-perf_results.csv}"

[[ -x "$BIN" ]] || die "Binary '$BIN' not found. Run ./build.sh first."

tmpdir="$(mktemp -d)"
trap 'rm -rf "${tmpdir}"' EXIT

echo "n,tasks,avg_serial_s,avg_simd_s,avg_task_time_s,simd_speedup,task_speedup_vs_serial,task_speedup_vs_simd" > "$CSV"

all_lines="$tmpdir/all_lines.txt"
: > "$all_lines"

for r in $(seq 1 "$REPS"); do
  msg "Run $r/$REPS…"
  out="$tmpdir/run_$r.txt"
  # Capture full program output
  "$BIN" | tee "$out" >/dev/null

  # Append only the machine-readable CSV lines
  grep -E '^CSV ' "$out" >> "$all_lines" || true
done

# Sanity check
if ! grep -q '^CSV ' "$all_lines"; then
  echo "No CSV lines captured. Try: ./$BIN | grep '^CSV '"
  echo "If none, rebuild with the CSV-enabled main."
  exit 1
fi

# Aggregate by (n,tasks)
# CSV lines look like:
# CSV n=10000000,tasks=4,serial=0.2043,simd=0.0452,task_time=0.0130,...
awk '
  BEGIN { FS="[ =,]"; OFS="," }
  /^CSV / {
    n=$3; t=$5; s=$7; i=$9; tt=$11;
    key = n ":" t
    cnt[key]++
    sumS[key]+=s; sumI[key]+=i; sumTT[key]+=tt
  }
  END {
    for (k in cnt) {
      # split key
      split(k, a, ":"); n=a[1]; t=a[2]
      avgS  = sumS[k]/cnt[k]
      avgI  = sumI[k]/cnt[k]
      avgTT = sumTT[k]/cnt[k]
      spSIMD  = (avgI  > 0 ? avgS/avgI  : 0)
      spTasks = (avgTT > 0 ? avgS/avgTT : 0)
      spVsSIMD= (avgTT > 0 ? avgI/avgTT : 0)
      print n, t, avgS, avgI, avgTT, spSIMD, spTasks, spVsSIMD
    }
  }
' "$all_lines" | sort -t, -k1,1n -k2,2n >> "$CSV"

msg "Wrote $CSV"
