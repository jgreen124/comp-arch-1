#pragma once

// Scalar baseline for correctness and speed up comparison
void square_root_serial(const float* input, float* output, int count);
