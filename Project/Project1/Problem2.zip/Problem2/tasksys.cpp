// tasksys.cpp — minimal POSIX runtime for ISPC launch[]
// Works with ISPC 1.22–1.29 (tested). Build with -pthread.

#include <pthread.h>
#include <vector>
#include <cstdint>
#include <cstdlib>
#include <cstring>

using ISPCTaskFunc = void (*)(void *data, int32_t threadIndex, int32_t threadCount);

struct ThreadInfo {
    ISPCTaskFunc func;
    void *data;
    int32_t threadIndex;
    int32_t threadCount;
};

static void *threadMain(void *arg) {
    ThreadInfo *ti = (ThreadInfo *)arg;
    ti->func(ti->data, ti->threadIndex, ti->threadCount);
    return nullptr;
}

extern "C" {

// Alloc opaque per-launch storage (ISPC may pass this back to ISPCSync)
void *ISPCAlloc(void **handlePtr, int32_t size) {
    void *mem = std::malloc((size_t)size);
    if (mem) std::memset(mem, 0, (size_t)size);
    if (handlePtr) *handlePtr = mem;
    return mem;
}

// Launch 'taskCount' parallel tasks. 'count' is unused by this tiny runtime.
void ISPCLaunch(void *f, void *data, int /*count*/, int32_t taskCount) {
    ISPCTaskFunc func = (ISPCTaskFunc)f;

    if (taskCount <= 1) {
        func(data, 0, 1);
        return;
    }

    std::vector<pthread_t> threads(taskCount - 1);
    std::vector<ThreadInfo> infos(taskCount);

    // Prepare stable ThreadInfo storage before creating threads
    for (int32_t i = 0; i < taskCount; ++i) {
        infos[i] = ThreadInfo{ func, data, i, taskCount };
    }

    // Spawn workers for indices [1..taskCount-1]
    for (int32_t i = 1; i < taskCount; ++i) {
        pthread_create(&threads[i - 1], nullptr, threadMain, &infos[i]);
    }

    // Run index 0 on the caller thread
    threadMain(&infos[0]);

    // Join workers
    for (auto &th : threads) pthread_join(th, nullptr);
}

// Sync hook after a launch group (no-op here)
void ISPCSync(void * /*handle*/) {}

} // extern "C"
